/* (c) Larry Herman, 2018.  You are allowed to use this code yourself, but
 * not to provide it to anyone else.
 */

int is_valid_triangle(int side1, int side2, int side3);
int gfn(int n0, int n1, int n);
